import 'package:flutter_test/flutter_test.dart';
import 'package:litecut/models/clip_segment.dart';
import 'package:litecut/models/edit_state.dart';
import 'package:litecut/models/music_track.dart';
import 'package:litecut/services/export_service.dart';

void main() {
  const a = ClipSegment(id: 'a', startMs: 0, endMs: 4000);
  const b = ClipSegment(id: 'b', startMs: 6000, endMs: 10000, speed: 2.0);
  const state = EditState(segments: [a, b]);

  test('total duration accounts for speed', () {
    expect(state.totalDurationMs, 4000 + 2000);
  });

  test('locate maps timeline time to segment + offset', () {
    expect(state.locate(1000), (index: 0, offsetMs: 1000));
    expect(state.locate(4000), (index: 1, offsetMs: 0)); // boundary -> next
    expect(state.locate(5000), (index: 1, offsetMs: 1000));
  });

  test('sourceTimeAt applies speed', () {
    expect(state.sourceTimeAt(5000), 6000 + 2000); // 1s into a 2x clip = 2s of source
  });

  test('json round trip', () {
    final s = state.copyWith(
      music: const MusicTrack(path: '/x.mp3', name: 'x', durationMs: 1000),
    );
    final back = EditState.fromJson(s.toJson());
    expect(back.segments.length, 2);
    expect(back.music?.name, 'x');
  });

  test('export graph contains concat, atempo and amix', () {
    final args = ExportService.buildArguments(
      input: '/in.mp4',
      output: '/out.mp4',
      edit: state.copyWith(
        music: const MusicTrack(path: '/m.mp3', name: 'm', durationMs: 5000, timelineStartMs: 500),
      ),
      width: 1080,
      height: 1920,
      hasAudio: true,
      overlayPngs: const [],
      settings: const ExportSettings(),
    );
    final graph = args[args.indexOf('-filter_complex') + 1];
    expect(graph, contains('concat=n=2'));
    expect(graph, contains('atempo=2.0000'));
    expect(graph, contains('amix=inputs=2'));
    expect(graph, contains('adelay=500'));
  });

  test('output size never upscales and is even', () {
    expect(ExportService.outputSize(3840, 2160, ExportResolution.p1080), (1920, 1080));
    expect(ExportService.outputSize(1280, 720, ExportResolution.p1080), (1280, 720));
  });
}
