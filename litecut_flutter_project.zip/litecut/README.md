# LiteCut – lightweight cross-platform video editor (Flutter)

Gallery import · split / trim / speed · background music · text captions ·
FFmpeg export saved to the gallery. Android + iOS.

## 1. Put the project together

```bash
flutter create --org com.example --project-name litecut litecut_app
cd litecut_app
```
Then copy from this archive into `litecut_app/`, replacing what exists:

* `pubspec.yaml`
* `analysis_options.yaml`
* the whole `lib/` folder (delete the generated `lib/main.dart` first)
* `test/edit_state_test.dart` (delete the generated `test/widget_test.dart`)

```bash
flutter pub get
```
> Package versions in `pubspec.yaml` were current when written. If `pub get`
> complains, run `flutter pub upgrade --major-versions`.

## 2. Platform configuration (required)

### Android
`android/app/build.gradle(.kts)` – FFmpegKit needs API 24+:
```kotlin
defaultConfig {
    minSdk = 24          // Groovy: minSdkVersion 24
}
```
`android/app/src/main/AndroidManifest.xml` – inside `<manifest>` (above `<application>`):
```xml
<!-- Only needed for saving to the gallery on Android 9 and below -->
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
                 android:maxSdkVersion="29" />
```
(Picking video/audio uses the system Photo Picker / document picker, so no
read-storage permission is needed.)

Release builds with R8: if export crashes only in release, add to
`android/app/proguard-rules.pro` (and reference it from your release
`buildTypes`):
```
-keep class com.antonkarpenko.ffmpegkit.** { *; }
-keep class com.arthenica.** { *; }
```

### iOS
`ios/Podfile`:
```ruby
platform :ios, '14.0'
```
`ios/Runner/Info.plist` – add inside the top-level `<dict>`:
```xml
<key>NSPhotoLibraryUsageDescription</key>
<string>LiteCut needs access to your photos to import videos.</string>
<key>NSPhotoLibraryAddUsageDescription</key>
<string>LiteCut saves your exported videos to your photo library.</string>
```
Then `cd ios && pod install --repo-update`.

## 3. Run
```bash
flutter run            # on a real device (emulators are slow for video)
flutter test           # timeline maths + FFmpeg graph tests
```

## 4. Architecture

```
lib/
  main.dart, app.dart          entry + providers
  core/        theme, formatting helpers
  models/      ClipSegment, MusicTrack, TextOverlay, EditState (immutable), Project
  services/    ProjectRepository (JSON on disk), MediaService (pickers, probe, thumbnails),
               TextRenderer (Flutter text -> PNG), ExportService (FFmpeg graph + gallery save)
  controllers/ ProjectsController (home), EditorController (edit logic + playback engine),
               ExportController (export progress)
  screens/     HomeScreen, EditorScreen
  widgets/     VideoPreview, TimelineView, EditorToolbar, sheets/ (trim, speed, audio, text, export)
```
* **Non-destructive**: edits are just numbers (`EditState`); the source file is
  untouched until export. Undo/redo = stack of `EditState` snapshots.
* **Preview sync**: a wall-clock master timeline drives the video player and the
  music player (both slaves, drift-corrected). See the comment at the top of
  `editor_controller.dart`.
* **Export**: one `-filter_complex` graph: per-segment `trim/setpts/atempo` →
  `concat` → text PNG `overlay` → `volume/adelay/amix` → H.264 + AAC.
* **Captions** are rendered by Flutter to PNG and composited by FFmpeg, so any
  language/emoji works and preview == export.

## 5. Known limitations / next steps
* Preview speed relies on the platform player's rate support (export is exact).
  Preview has a brief hitch where playback jumps between non-adjacent clips.
* One music track; clips stay in source order (no reordering / multiple video tracks).
* Caption times don't ripple when you later split/trim/delete earlier clips.
* Export runs in the foreground; keep the app open (OS may kill background FFmpeg).
* **Licensing**: the default `ffmpeg_kit_flutter_new` build is Full-GPL (x264).
  If you ship commercially, review GPL obligations or switch to an LGPL variant
  and enable "Hardware encoder" (MediaCodec / VideoToolbox) instead of libx264.
* APK size is large because FFmpeg is bundled: ship with `--split-per-abi` / AAB.
