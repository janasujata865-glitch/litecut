import 'package:flutter/material.dart';

/// Formats milliseconds as `m:ss` (or `m:ss.t` when [tenths] is true).
String formatMs(int ms, {bool tenths = false}) {
  final safe = ms < 0 ? 0 : ms;
  final totalSeconds = safe ~/ 1000;
  final m = totalSeconds ~/ 60;
  final s = totalSeconds % 60;
  final base = '$m:${s.toString().padLeft(2, '0')}';
  return tenths ? '$base.${(safe % 1000) ~/ 100}' : base;
}

int clampInt(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);

/// Shows a floating snackbar when [message] is non-null (handy for `String?` results).
void showToast(BuildContext context, String? message) {
  if (message == null) return;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}
