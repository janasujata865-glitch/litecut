import 'package:flutter/material.dart';

class AppColors {
  static const background = Color(0xFF0E0E12);
  static const surface = Color(0xFF1A1A22);
  static const surfaceHigh = Color(0xFF262633);
  static const accent = Color(0xFF8E7CFF);
  static const teal = Color(0xFF14B8A6);
  static const amber = Color(0xFFF59E0B);
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.accent,
    brightness: Brightness.dark,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.background,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.background,
      elevation: 0,
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}
