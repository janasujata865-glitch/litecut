import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:gal/gal.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/edit_state.dart';
import '../models/project.dart';
import 'text_renderer.dart';

enum ExportResolution { original, p1080, p720 }

enum ExportQuality { high, balanced, small }

class ExportSettings {
  const ExportSettings({
    this.resolution = ExportResolution.original,
    this.quality = ExportQuality.high,
    this.fps = 30,
    this.useHardwareEncoder = false,
  });

  final ExportResolution resolution;
  final ExportQuality quality;
  final int fps;

  /// MediaCodec (Android) / VideoToolbox (iOS). Much faster, slightly larger
  /// files at the same quality. Software x264 is the default for best quality.
  final bool useHardwareEncoder;

  ExportSettings copyWith({
    ExportResolution? resolution,
    ExportQuality? quality,
    int? fps,
    bool? useHardwareEncoder,
  }) =>
      ExportSettings(
        resolution: resolution ?? this.resolution,
        quality: quality ?? this.quality,
        fps: fps ?? this.fps,
        useHardwareEncoder: useHardwareEncoder ?? this.useHardwareEncoder,
      );
}

class ExportCancelled implements Exception {}

class ExportFailure implements Exception {
  ExportFailure(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Turns an [EditState] into ONE FFmpeg `-filter_complex` command and runs it.
///
/// Graph overview:
///   per segment : trim -> setpts(speed) -> fps -> scale          (video)
///                 atrim -> asetpts -> atempo chain               (audio)
///   concat all segments
///   overlay each text PNG with enable='between(t,start,end)'
///   volume(original) + adelay/volume(music) -> amix
class ExportService {
  int? _sessionId;
  bool _cancelled = false;
  final TextRenderer _renderer = TextRenderer();

  Future<String> export({
    required Project project,
    required EditState edit,
    required ExportSettings settings,
    required void Function(double progress) onProgress,
  }) async {
    _cancelled = false;
    final tmp = await getTemporaryDirectory();
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final workDir = Directory(p.join(tmp.path, 'export_$stamp'));
    await workDir.create(recursive: true);

    try {
      final (w, h) = outputSize(project.width, project.height, settings.resolution);
      final totalMs = edit.totalDurationMs;

      // 1) Render every caption to a transparent, full-frame PNG.
      final overlays = [
        for (final o in edit.overlays)
          if (o.startMs < totalMs && o.text.trim().isNotEmpty) o,
      ];
      final pngs = <File>[];
      for (var i = 0; i < overlays.length; i++) {
        pngs.add(await _renderer.renderToPng(
            overlays[i], w, h, p.join(workDir.path, 'text_$i.png')));
      }

      // 2) Build + run the FFmpeg command.
      final output = p.join(tmp.path, 'litecut_$stamp.mp4');
      final args = buildArguments(
        input: project.sourcePath,
        output: output,
        edit: edit.copyWith(overlays: overlays),
        width: w,
        height: h,
        hasAudio: project.hasAudio,
        overlayPngs: pngs.map((f) => f.path).toList(),
        settings: settings,
      );
      await _run(args, totalMs, onProgress);
      return output;
    } finally {
      try {
        await workDir.delete(recursive: true);
      } catch (_) {}
    }
  }

  Future<void> cancel() async {
    _cancelled = true;
    await FFmpegKit.cancel(_sessionId);
  }

  /// Saves to the system gallery (Photos on iOS, MediaStore on Android).
  Future<void> saveToGallery(String path) async {
    if (!await Gal.hasAccess(toAlbum: true)) {
      final granted = await Gal.requestAccess(toAlbum: true);
      if (!granted) throw ExportFailure('Gallery permission was denied.');
    }
    await Gal.putVideo(path, album: 'LiteCut');
    try {
      await File(path).delete();
    } catch (_) {}
  }

  // ------------------------------------------------------------------ helpers

  /// Never upscales; keeps aspect ratio; forces even dimensions (yuv420p needs it).
  static (int, int) outputSize(int w, int h, ExportResolution r) {
    final shortSide = math.min(w, h);
    final cap = switch (r) {
      ExportResolution.original => shortSide,
      ExportResolution.p1080 => 1080,
      ExportResolution.p720 => 720,
    };
    final scale = cap >= shortSide ? 1.0 : cap / shortSide;
    int even(double v) {
      final i = v.round();
      return i.isOdd ? i + 1 : i;
    }

    return (even(w * scale), even(h * scale));
  }

  static String _sec(int ms) => (ms / 1000).toStringAsFixed(3);

  /// FFmpeg's `atempo` only accepts 0.5-2.0 per instance, so chain them.
  static String _atempoChain(double speed) {
    if ((speed - 1.0).abs() < 0.001) return '';
    final parts = <String>[];
    var s = speed;
    while (s < 0.5) {
      parts.add('atempo=0.5');
      s /= 0.5;
    }
    while (s > 2.0) {
      parts.add('atempo=2.0');
      s /= 2.0;
    }
    parts.add('atempo=${s.toStringAsFixed(4)}');
    return '${parts.join(',')},';
  }

  static List<String> _videoEncoderArgs(int w, int h, ExportSettings s) {
    if (!s.useHardwareEncoder) {
      final crf = switch (s.quality) {
        ExportQuality.high => '17',
        ExportQuality.balanced => '21',
        ExportQuality.small => '26',
      };
      return ['-c:v', 'libx264', '-preset', 'medium', '-crf', crf,
        '-profile:v', 'high', '-pix_fmt', 'yuv420p'];
    }
    final bitsPerPixel = switch (s.quality) {
      ExportQuality.high => 0.16,
      ExportQuality.balanced => 0.10,
      ExportQuality.small => 0.06,
    };
    final bitrate = (w * h * s.fps * bitsPerPixel).round();
    final encoder = Platform.isIOS ? 'h264_videotoolbox' : 'h264_mediacodec';
    return ['-c:v', encoder, '-b:v', '$bitrate', '-pix_fmt', 'yuv420p'];
  }

  /// Pure function (no I/O) so it can be unit tested.
  static List<String> buildArguments({
    required String input,
    required String output,
    required EditState edit,
    required int width,
    required int height,
    required bool hasAudio,
    required List<String> overlayPngs,
    required ExportSettings settings,
  }) {
    final segs = edit.segments;
    final totalMs = edit.totalDurationMs;
    final music = edit.music;

    // ---- inputs: 0 = video, 1..n = text PNGs, last = music
    final args = <String>['-y', '-i', input];
    for (final png in overlayPngs) {
      args.addAll(['-i', png]);
    }
    final musicIndex = 1 + overlayPngs.length;
    if (music != null) args.addAll(['-i', music.path]);

    final f = <String>[];

    // ---- per-segment video + audio
    for (var i = 0; i < segs.length; i++) {
      final s = segs[i];
      final a = _sec(s.startMs), b = _sec(s.endMs);
      f.add('[0:v]trim=start=$a:end=$b,setpts=(PTS-STARTPTS)/${s.speed},'
          'fps=${settings.fps},scale=$width:$height:flags=lanczos,setsar=1[v$i]');
      if (hasAudio) {
        f.add('[0:a]atrim=start=$a:end=$b,asetpts=PTS-STARTPTS,'
            '${_atempoChain(s.speed)}'
            'aformat=sample_rates=44100:channel_layouts=stereo[a$i]');
      } else {
        // Source has no audio: generate silence of the right length so concat works.
        f.add('anullsrc=r=44100:cl=stereo,atrim=duration=${_sec(s.timelineDurationMs)},'
            'asetpts=PTS-STARTPTS[a$i]');
      }
    }
    final pads = List.generate(segs.length, (i) => '[v$i][a$i]').join();
    f.add('${pads}concat=n=${segs.length}:v=1:a=1[vc][ac]');

    // ---- text overlays
    var vLabel = 'vc';
    for (var k = 0; k < overlayPngs.length; k++) {
      final o = edit.overlays[k];
      final start = _sec(o.startMs);
      final end = _sec(math.min(o.endMs, totalMs));
      f.add("[$vLabel][${k + 1}:v]overlay=0:0:format=auto:"
          "enable='between(t,$start,$end)'[vo$k]");
      vLabel = 'vo$k';
    }
    f.add('[$vLabel]format=yuv420p[vout]');

    // ---- audio mix
    f.add('[ac]volume=${edit.originalVolume.toStringAsFixed(2)}[am]');
    if (music != null) {
      final d = music.timelineStartMs;
      f.add('[$musicIndex:a]aformat=sample_rates=44100:channel_layouts=stereo,'
          'adelay=$d:all=1,volume=${music.volume.toStringAsFixed(2)}[mu]');
      // duration=first => output ends with the video even if the music is longer.
      // normalize=0 keeps the levels the user chose (FFmpeg >= 7.1).
      f.add('[am][mu]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]');
    } else {
      f.add('[am]anull[aout]');
    }

    args
      ..addAll(['-filter_complex', f.join(';')])
      ..addAll(['-map', '[vout]', '-map', '[aout]'])
      ..addAll(_videoEncoderArgs(width, height, settings))
      ..addAll(['-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', output]);
    return args;
  }

  Future<void> _run(
    List<String> args,
    int totalMs,
    void Function(double) onProgress,
  ) {
    final done = Completer<void>();
    final logs = <String>[];

    unawaited(FFmpegKit.executeWithArgumentsAsync(
      args,
      (session) async {
        final rc = await session.getReturnCode();
        if (done.isCompleted) return;
        if (ReturnCode.isSuccess(rc)) {
          done.complete();
        } else if (_cancelled || ReturnCode.isCancel(rc)) {
          done.completeError(ExportCancelled());
        } else {
          final tail = logs.length > 12 ? logs.sublist(logs.length - 12) : logs;
          done.completeError(ExportFailure(
              'FFmpeg failed (code ${rc?.getValue()}).\n${tail.join().trim()}'));
        }
      },
      (log) {
        logs.add(log.getMessage());
        if (logs.length > 200) logs.removeAt(0);
      },
      (stats) {
        final num t = stats.getTime(); // milliseconds of output written so far
        if (totalMs > 0 && t > 0) onProgress(math.min(0.99, t / totalMs));
      },
    ).then((session) {
      _sessionId = session.getSessionId();
    }).catchError((Object e) {
      if (!done.isCompleted) done.completeError(ExportFailure('$e'));
    }));

    return done.future;
  }
}
