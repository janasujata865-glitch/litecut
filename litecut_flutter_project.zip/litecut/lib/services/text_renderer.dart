import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/painting.dart';

import '../models/text_overlay.dart';

/// Renders a text overlay to a full-frame transparent PNG.
///
/// WHY a PNG instead of FFmpeg's `drawtext`?
///  * works with ANY script (Bengali, Hindi, Arabic, emoji...) because Flutter
///    uses the system's font fallback; `drawtext` needs a bundled font file
///  * preview and export are pixel-identical (same TextStyle, same layout engine)
///  * no font-path headaches on iOS
/// FFmpeg then just composites the PNG with the `overlay` filter.
class TextRenderer {
  Future<File> renderToPng(TextOverlay o, int width, int height, String outPath) async {
    final shortSide = math.min(width, height).toDouble();

    final painter = TextPainter(
      text: TextSpan(text: o.text, style: o.style(shortSide)),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: width * 0.9);

    final recorder = ui.PictureRecorder();
    final canvas = Canvas(
      recorder,
      Rect.fromLTWH(0, 0, width.toDouble(), height.toDouble()),
    );
    painter.paint(
      canvas,
      Offset(o.dx * width - painter.width / 2, o.dy * height - painter.height / 2),
    );

    final image = await recorder.endRecording().toImage(width, height);
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    painter.dispose();

    final file = File(outPath);
    await file.writeAsBytes(bytes!.buffer.asUint8List(), flush: true);
    return file;
  }
}
