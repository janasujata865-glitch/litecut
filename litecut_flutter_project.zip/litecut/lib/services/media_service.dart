import 'dart:io';
import 'dart:math' as math;

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:video_player/video_player.dart';

class VideoMeta {
  const VideoMeta({required this.durationMs, required this.width, required this.height});
  final int durationMs;
  final int width;
  final int height;
}

/// Everything that touches pickers, probing and thumbnails.
class MediaService {
  final ImagePicker _picker = ImagePicker();

  /// Opens the system gallery picker (Android Photo Picker / iOS PHPicker).
  /// Returns a readable file path, or null if the user cancelled.
  Future<String?> pickVideo() async {
    final file = await _picker.pickVideo(source: ImageSource.gallery);
    return file?.path;
  }

  /// Opens the system document picker filtered to audio files.
  Future<({String path, String name})?> pickAudio() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
      allowMultiple: false,
    );
    final f = result?.files.single;
    if (f == null || f.path == null) return null;
    return (path: f.path!, name: f.name);
  }

  /// Duration + DISPLAY size. video_player already corrects for rotation
  /// metadata, which is exactly what FFmpeg's autorotate produces on export.
  Future<VideoMeta> readVideoMeta(String path) async {
    final c = VideoPlayerController.file(File(path));
    try {
      await c.initialize();
      return VideoMeta(
        durationMs: c.value.duration.inMilliseconds,
        width: c.value.size.width.round(),
        height: c.value.size.height.round(),
      );
    } finally {
      await c.dispose();
    }
  }

  /// True if the file has an audio stream (affects how export builds its graph).
  Future<bool> hasAudioStream(String path) async {
    try {
      final session = await FFprobeKit.getMediaInformation(path);
      final streams = session.getMediaInformation()?.getStreams() ?? [];
      return streams.any((s) => s.getType() == 'audio');
    } catch (_) {
      return true;
    }
  }

  Future<String?> extractThumbnail(String input, String output,
      {int atMs = 0, int width = 480}) async {
    final session = await FFmpegKit.executeWithArguments([
      '-y', '-ss', (atMs / 1000).toStringAsFixed(3), '-i', input,
      '-frames:v', '1', '-vf', 'scale=$width:-2', '-q:v', '3', output,
    ]);
    final rc = await session.getReturnCode();
    return ReturnCode.isSuccess(rc) && File(output).existsSync() ? output : null;
  }

  /// Generates evenly spaced preview frames for the timeline filmstrip.
  /// Cached on disk: re-opening a project doesn't re-render them.
  Future<List<String>> generateFilmstrip(
      String input, Directory outDir, int durationMs) async {
    final durSec = math.max(durationMs / 1000, 0.1);
    final count = math.min(60, math.max(8, durSec.ceil()));
    List<String> files() => [
          for (var i = 1; i <= count; i++)
            p.join(outDir.path, 'strip_${i.toString().padLeft(3, '0')}.jpg'),
        ];

    if (files().every((f) => File(f).existsSync())) return files();

    final session = await FFmpegKit.executeWithArguments([
      '-y', '-i', input, '-an',
      '-vf', 'fps=${(count / durSec).toStringAsFixed(6)},scale=-2:120',
      '-frames:v', '$count', '-q:v', '5',
      p.join(outDir.path, 'strip_%03d.jpg'),
    ]);
    if (!ReturnCode.isSuccess(await session.getReturnCode())) return [];

    // ffmpeg can emit slightly fewer frames than requested; keep what exists.
    return files().where((f) => File(f).existsSync()).toList();
  }
}
