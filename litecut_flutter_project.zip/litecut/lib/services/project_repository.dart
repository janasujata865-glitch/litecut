import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/project.dart';

/// Persists projects as JSON and owns the on-disk folder layout:
///
///   <documents>/litecut/projects.json
///   <documents>/litecut/projects/<id>/source.mp4, thumb.jpg, strip/, music_*.mp3
class ProjectRepository {
  Directory? _root;
  Future<void> _writeChain = Future.value();

  Future<Directory> _rootDir() async {
    final cached = _root;
    if (cached != null) return cached;
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'litecut'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return _root = dir;
  }

  Future<Directory> projectDir(String id) async {
    final root = await _rootDir();
    final dir = Directory(p.join(root.path, 'projects', id));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// iOS can change the app container path between launches/updates, so stored
  /// absolute paths are re-based onto the current documents directory.
  String _rebase(String path, String root) {
    const marker = '/litecut/';
    final i = path.indexOf(marker);
    if (i < 0) return path;
    return p.join(root, path.substring(i + marker.length));
  }

  Future<List<Project>> load() async {
    final root = await _rootDir();
    final file = File(p.join(root.path, 'projects.json'));
    if (!await file.exists()) return [];
    try {
      final raw = jsonDecode(await file.readAsString()) as List;
      final result = <Project>[];
      for (final e in raw) {
        var project = Project.fromJson(e as Map<String, dynamic>);
        final music = project.edit.music;
        project = project.copyWith(
          sourcePath: _rebase(project.sourcePath, root.path),
          thumbnailPath: project.thumbnailPath == null
              ? null
              : _rebase(project.thumbnailPath!, root.path),
          edit: music == null
              ? project.edit
              : project.edit.copyWith(
                  music: music.copyWith(path: _rebase(music.path, root.path))),
        );
        if (File(project.sourcePath).existsSync()) result.add(project);
      }
      return result;
    } catch (_) {
      return [];
    }
  }

  /// Serialised + atomic (write temp file then rename) so a crash mid-write
  /// can never corrupt the project list.
  Future<void> save(List<Project> projects) {
    final snapshot = jsonEncode(projects.map((e) => e.toJson()).toList());
    _writeChain = _writeChain.then((_) async {
      final root = await _rootDir();
      final tmp = File(p.join(root.path, 'projects.json.tmp'));
      await tmp.writeAsString(snapshot, flush: true);
      await tmp.rename(p.join(root.path, 'projects.json'));
    }).catchError((Object _) {});
    return _writeChain;
  }

  Future<void> deleteProjectFiles(String id) async {
    final dir = await projectDir(id);
    if (await dir.exists()) await dir.delete(recursive: true);
  }
}
