import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // The editor UI is designed for portrait phones.
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const LiteCutApp());
}
