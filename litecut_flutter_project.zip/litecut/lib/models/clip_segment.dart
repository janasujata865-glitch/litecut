/// One piece of the source video on the timeline.
///
/// The editor is NON-DESTRUCTIVE: splitting/trimming/speed only change these
/// numbers. The source file is never touched until export.
class ClipSegment {
  const ClipSegment({
    required this.id,
    required this.startMs,
    required this.endMs,
    this.speed = 1.0,
  });

  final String id;

  /// In/out points inside the SOURCE video (milliseconds).
  final int startMs;
  final int endMs;

  /// 0.25 = slow motion, 2.0 = fast forward.
  final double speed;

  int get sourceDurationMs => endMs - startMs;

  /// How long this segment lasts on the timeline after the speed change.
  int get timelineDurationMs => (sourceDurationMs / speed).round();

  ClipSegment copyWith({String? id, int? startMs, int? endMs, double? speed}) =>
      ClipSegment(
        id: id ?? this.id,
        startMs: startMs ?? this.startMs,
        endMs: endMs ?? this.endMs,
        speed: speed ?? this.speed,
      );

  Map<String, dynamic> toJson() =>
      {'id': id, 'startMs': startMs, 'endMs': endMs, 'speed': speed};

  factory ClipSegment.fromJson(Map<String, dynamic> j) => ClipSegment(
        id: j['id'] as String,
        startMs: j['startMs'] as int,
        endMs: j['endMs'] as int,
        speed: (j['speed'] as num).toDouble(),
      );
}
