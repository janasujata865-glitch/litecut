/// A background-music / audio track placed on the timeline.
class MusicTrack {
  const MusicTrack({
    required this.path,
    required this.name,
    required this.durationMs,
    this.timelineStartMs = 0,
    this.volume = 1.0,
  });

  final String path;
  final String name;
  final int durationMs;

  /// Where the music begins on the TIMELINE (not in the audio file).
  final int timelineStartMs;

  /// 0.0 - 1.0
  final double volume;

  MusicTrack copyWith({
    String? path,
    String? name,
    int? durationMs,
    int? timelineStartMs,
    double? volume,
  }) =>
      MusicTrack(
        path: path ?? this.path,
        name: name ?? this.name,
        durationMs: durationMs ?? this.durationMs,
        timelineStartMs: timelineStartMs ?? this.timelineStartMs,
        volume: volume ?? this.volume,
      );

  Map<String, dynamic> toJson() => {
        'path': path,
        'name': name,
        'durationMs': durationMs,
        'timelineStartMs': timelineStartMs,
        'volume': volume,
      };

  factory MusicTrack.fromJson(Map<String, dynamic> j) => MusicTrack(
        path: j['path'] as String,
        name: j['name'] as String,
        durationMs: j['durationMs'] as int,
        timelineStartMs: j['timelineStartMs'] as int,
        volume: (j['volume'] as num).toDouble(),
      );
}
