import 'package:flutter/painting.dart';

/// A text caption shown on top of the video between [startMs] and [endMs]
/// (timeline time).
///
/// Position is stored NORMALISED (0..1) relative to the video frame so it is
/// resolution independent: the same overlay looks identical in the preview and
/// in a 4K export.
class TextOverlay {
  const TextOverlay({
    required this.id,
    required this.text,
    required this.startMs,
    required this.endMs,
    this.fontSize = 64,
    this.color = const Color(0xFFFFFFFF),
    this.bold = true,
    this.background = false,
    this.dx = 0.5,
    this.dy = 0.5,
  });

  final String id;
  final String text;
  final int startMs;
  final int endMs;

  /// Font size in "points on a 1080px short-side frame".
  final double fontSize;
  final Color color;
  final bool bold;
  final bool background;

  /// Centre of the text box, 0..1 of frame width / height.
  final double dx;
  final double dy;

  /// The ONE place text style is defined. Both the live preview (Text widget)
  /// and the export renderer (TextPainter) call this, so they always match.
  TextStyle style(double frameShortSide) {
    final scale = frameShortSide / 1080.0;
    return TextStyle(
      fontSize: fontSize * scale,
      color: color,
      fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
      height: 1.2,
      decoration: TextDecoration.none,
      backgroundColor: background ? const Color(0x99000000) : null,
      shadows: background
          ? null
          : [
              Shadow(
                color: const Color(0xCC000000),
                blurRadius: 6 * scale,
                offset: Offset(0, 2 * scale),
              ),
            ],
    );
  }

  TextOverlay copyWith({
    String? text,
    int? startMs,
    int? endMs,
    double? fontSize,
    Color? color,
    bool? bold,
    bool? background,
    double? dx,
    double? dy,
  }) =>
      TextOverlay(
        id: id,
        text: text ?? this.text,
        startMs: startMs ?? this.startMs,
        endMs: endMs ?? this.endMs,
        fontSize: fontSize ?? this.fontSize,
        color: color ?? this.color,
        bold: bold ?? this.bold,
        background: background ?? this.background,
        dx: dx ?? this.dx,
        dy: dy ?? this.dy,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'text': text,
        'startMs': startMs,
        'endMs': endMs,
        'fontSize': fontSize,
        'color': color.toARGB32(),
        'bold': bold,
        'background': background,
        'dx': dx,
        'dy': dy,
      };

  factory TextOverlay.fromJson(Map<String, dynamic> j) => TextOverlay(
        id: j['id'] as String,
        text: j['text'] as String,
        startMs: j['startMs'] as int,
        endMs: j['endMs'] as int,
        fontSize: (j['fontSize'] as num).toDouble(),
        color: Color(j['color'] as int),
        bold: j['bold'] as bool,
        background: j['background'] as bool,
        dx: (j['dx'] as num).toDouble(),
        dy: (j['dy'] as num).toDouble(),
      );
}
