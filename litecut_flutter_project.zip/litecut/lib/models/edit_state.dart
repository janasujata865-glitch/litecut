import 'dart:math' as math;

import 'clip_segment.dart';
import 'music_track.dart';
import 'text_overlay.dart';

/// Immutable snapshot of everything the user can edit.
/// Undo/redo is simply a stack of these snapshots.
class EditState {
  const EditState({
    required this.segments,
    this.overlays = const [],
    this.music,
    this.originalVolume = 1.0,
  });

  /// A fresh project: one segment covering the whole source video.
  factory EditState.initial(int sourceDurationMs, String segmentId) => EditState(
        segments: [ClipSegment(id: segmentId, startMs: 0, endMs: sourceDurationMs)],
      );

  final List<ClipSegment> segments;
  final List<TextOverlay> overlays;
  final MusicTrack? music;

  /// Volume of the video's own audio, 0..1.
  final double originalVolume;

  /// Length of the final video (sum of all segments after speed changes).
  int get totalDurationMs =>
      segments.fold(0, (sum, s) => sum + s.timelineDurationMs);

  /// Timeline time at which segment [index] begins.
  int segmentStartOnTimeline(int index) {
    var t = 0;
    for (var i = 0; i < index && i < segments.length; i++) {
      t += segments[i].timelineDurationMs;
    }
    return t;
  }

  /// Which segment is playing at [timelineMs], and how far into it (in
  /// TIMELINE milliseconds). A time exactly on a boundary belongs to the next
  /// segment; times past the end map to the end of the last segment.
  ({int index, int offsetMs}) locate(int timelineMs) {
    var acc = 0;
    for (var i = 0; i < segments.length; i++) {
      final d = segments[i].timelineDurationMs;
      if (timelineMs < acc + d || i == segments.length - 1) {
        return (index: i, offsetMs: math.max(0, math.min(timelineMs - acc, d)));
      }
      acc += d;
    }
    return (index: 0, offsetMs: 0);
  }

  /// Converts a timeline time into the matching SOURCE video time.
  int sourceTimeAt(int timelineMs) {
    final loc = locate(timelineMs);
    final s = segments[loc.index];
    return s.startMs + (loc.offsetMs * s.speed).round();
  }

  EditState updateSegment(String id, ClipSegment Function(ClipSegment) f) =>
      copyWith(segments: [for (final s in segments) s.id == id ? f(s) : s]);

  EditState updateOverlay(String id, TextOverlay Function(TextOverlay) f) =>
      copyWith(overlays: [for (final o in overlays) o.id == id ? f(o) : o]);

  EditState copyWith({
    List<ClipSegment>? segments,
    List<TextOverlay>? overlays,
    MusicTrack? music,
    bool clearMusic = false,
    double? originalVolume,
  }) =>
      EditState(
        segments: segments ?? this.segments,
        overlays: overlays ?? this.overlays,
        music: clearMusic ? null : (music ?? this.music),
        originalVolume: originalVolume ?? this.originalVolume,
      );

  Map<String, dynamic> toJson() => {
        'segments': segments.map((e) => e.toJson()).toList(),
        'overlays': overlays.map((e) => e.toJson()).toList(),
        'music': music?.toJson(),
        'originalVolume': originalVolume,
      };

  factory EditState.fromJson(Map<String, dynamic> j) => EditState(
        segments: (j['segments'] as List)
            .map((e) => ClipSegment.fromJson(e as Map<String, dynamic>))
            .toList(),
        overlays: (j['overlays'] as List)
            .map((e) => TextOverlay.fromJson(e as Map<String, dynamic>))
            .toList(),
        music: j['music'] == null
            ? null
            : MusicTrack.fromJson(j['music'] as Map<String, dynamic>),
        originalVolume: (j['originalVolume'] as num).toDouble(),
      );
}
