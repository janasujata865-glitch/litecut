import 'edit_state.dart';

/// A saved editing project: the imported source video + the edit decisions.
class Project {
  const Project({
    required this.id,
    required this.name,
    required this.sourcePath,
    required this.sourceDurationMs,
    required this.width,
    required this.height,
    required this.hasAudio,
    required this.createdAt,
    required this.updatedAt,
    required this.edit,
    this.thumbnailPath,
  });

  final String id;
  final String name;
  final String sourcePath;
  final String? thumbnailPath;
  final int sourceDurationMs;

  /// Display size (already rotation-corrected).
  final int width;
  final int height;
  final bool hasAudio;
  final DateTime createdAt;
  final DateTime updatedAt;
  final EditState edit;

  Project copyWith({
    String? name,
    String? sourcePath,
    String? thumbnailPath,
    DateTime? updatedAt,
    EditState? edit,
  }) =>
      Project(
        id: id,
        name: name ?? this.name,
        sourcePath: sourcePath ?? this.sourcePath,
        thumbnailPath: thumbnailPath ?? this.thumbnailPath,
        sourceDurationMs: sourceDurationMs,
        width: width,
        height: height,
        hasAudio: hasAudio,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        edit: edit ?? this.edit,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'sourcePath': sourcePath,
        'thumbnailPath': thumbnailPath,
        'sourceDurationMs': sourceDurationMs,
        'width': width,
        'height': height,
        'hasAudio': hasAudio,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'edit': edit.toJson(),
      };

  factory Project.fromJson(Map<String, dynamic> j) => Project(
        id: j['id'] as String,
        name: j['name'] as String,
        sourcePath: j['sourcePath'] as String,
        thumbnailPath: j['thumbnailPath'] as String?,
        sourceDurationMs: j['sourceDurationMs'] as int,
        width: j['width'] as int,
        height: j['height'] as int,
        hasAudio: j['hasAudio'] as bool,
        createdAt: DateTime.parse(j['createdAt'] as String),
        updatedAt: DateTime.parse(j['updatedAt'] as String),
        edit: EditState.fromJson(j['edit'] as Map<String, dynamic>),
      );
}
