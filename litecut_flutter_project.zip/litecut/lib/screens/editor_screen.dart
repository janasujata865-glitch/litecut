import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/editor_controller.dart';
import '../controllers/projects_controller.dart';
import '../core/format.dart';
import '../core/theme.dart';
import '../models/project.dart';
import '../services/media_service.dart';
import '../services/project_repository.dart';
import '../widgets/editor_toolbar.dart';
import '../widgets/sheets/sheets.dart';
import '../widgets/timeline_view.dart';
import '../widgets/video_preview.dart';

/// Hosts the [EditorController] for one project.
class EditorScreen extends StatelessWidget {
  const EditorScreen({super.key, required this.project});
  final Project project;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<EditorController>(
      create: (ctx) => EditorController(
        project: project,
        projects: ctx.read<ProjectsController>(),
        media: ctx.read<MediaService>(),
        repo: ctx.read<ProjectRepository>(),
      )..init(),
      child: const _EditorView(),
    );
  }
}

class _EditorView extends StatelessWidget {
  const _EditorView();

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    return Scaffold(
      body: SafeArea(
        child: c.initError != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text('Could not open this video.\n\n${c.initError}', textAlign: TextAlign.center),
                ),
              )
            : !c.ready
                ? const Center(child: CircularProgressIndicator())
                : Column(
                    children: [
                      const _TopBar(),
                      Expanded(
                        child: Center(
                          child: VideoPreview(onEditOverlay: (id) => openTextSheet(context, id)),
                        ),
                      ),
                      const _TransportBar(),
                      TimelineView(
                        onEditOverlay: (id) => openTextSheet(context, id),
                        onOpenAudio: () => openAudioSheet(context),
                      ),
                      const EditorToolbar(),
                    ],
                  ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar();

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: Row(
        children: [
          IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.of(context).pop()),
          const Spacer(),
          IconButton(icon: const Icon(Icons.undo), onPressed: c.canUndo ? c.undo : null),
          IconButton(icon: const Icon(Icons.redo), onPressed: c.canRedo ? c.redo : null),
          const SizedBox(width: 6),
          FilledButton.icon(
            onPressed: () async {
              await c.pause();
              if (context.mounted) openExportSheet(context);
            },
            icon: const Icon(Icons.file_upload_outlined, size: 18),
            label: const Text('Export'),
          ),
          const SizedBox(width: 8),
        ],
      ),
    );
  }
}

class _TransportBar extends StatelessWidget {
  const _TransportBar();

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    return Container(
      color: AppColors.surface,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      child: Row(
        children: [
          Text(
            '${formatMs(c.positionMs, tenths: true)} / ${formatMs(c.totalMs)}',
            style: const TextStyle(fontFeatures: [FontFeature.tabularFigures()], color: Colors.white70),
          ),
          const Spacer(),
          IconButton.filled(
            iconSize: 28,
            onPressed: c.togglePlay,
            icon: Icon(c.isPlaying ? Icons.pause : Icons.play_arrow),
          ),
          const Spacer(),
          IconButton(icon: const Icon(Icons.zoom_out), onPressed: c.zoomOut),
          IconButton(icon: const Icon(Icons.zoom_in), onPressed: c.zoomIn),
        ],
      ),
    );
  }
}
