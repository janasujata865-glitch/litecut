import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/projects_controller.dart';
import '../core/format.dart';
import '../core/theme.dart';
import '../models/project.dart';
import 'editor_screen.dart';

/// Dashboard: "Create New Project" + recent projects grid.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> _create(BuildContext context) async {
    final controller = context.read<ProjectsController>();
    final navigator = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    try {
      final project = await controller.createFromGallery();
      if (project == null) return; // picker cancelled
      await navigator.push(MaterialPageRoute(builder: (_) => EditorScreen(project: project)));
      controller.refresh();
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Could not import video: $e')));
    }
  }

  Future<void> _open(BuildContext context, Project project) async {
    final controller = context.read<ProjectsController>();
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => EditorScreen(project: project)));
    controller.refresh();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.watch<ProjectsController>();
    return Scaffold(
      body: Stack(
        children: [
          SafeArea(
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
                    child: Row(
                      children: [
                        const Icon(Icons.movie_edit, color: AppColors.accent, size: 28),
                        const SizedBox(width: 10),
                        Text('LiteCut',
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
                    child: _CreateCard(onTap: () => _create(context)),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
                    child: Text('Recent projects',
                        style: Theme.of(context).textTheme.titleMedium),
                  ),
                ),
                if (c.loading)
                  const SliverToBoxAdapter(
                      child: Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator())))
                else if (c.projects.isEmpty)
                  const SliverToBoxAdapter(child: _EmptyState())
                else
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                    sliver: SliverGrid.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: 0.78,
                      ),
                      itemCount: c.projects.length,
                      itemBuilder: (_, i) => _ProjectCard(
                        project: c.projects[i],
                        onTap: () => _open(context, c.projects[i]),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          if (c.importing)
            const ColoredBox(
              color: Color(0xCC000000),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 16),
                    Text('Importing video…'),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _CreateCard extends StatelessWidget {
  const _CreateCard({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: BorderRadius.circular(24),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Ink(
          height: 150,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF6C5CE7), Color(0xFF00B4D8)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: const Padding(
            padding: EdgeInsets.all(22),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: Colors.white24,
                  child: Icon(Icons.add, size: 34, color: Colors.white),
                ),
                SizedBox(width: 18),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Create New Project',
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Colors.white)),
                      SizedBox(height: 4),
                      Text('Pick a video from your gallery',
                          style: TextStyle(color: Colors.white70)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();
  @override
  Widget build(BuildContext context) => const Padding(
        padding: EdgeInsets.symmetric(vertical: 48, horizontal: 32),
        child: Column(
          children: [
            Icon(Icons.video_library_outlined, size: 56, color: Colors.white24),
            SizedBox(height: 12),
            Text('No projects yet.\nTap “Create New Project” to start editing.',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.white54)),
          ],
        ),
      );
}

class _ProjectCard extends StatelessWidget {
  const _ProjectCard({required this.project, required this.onTap});
  final Project project;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final thumb = project.thumbnailPath;
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          fit: StackFit.expand,
          children: [
            thumb != null && File(thumb).existsSync()
                ? Image.file(File(thumb), fit: BoxFit.cover, cacheWidth: 480)
                : const ColoredBox(color: AppColors.surfaceHigh, child: Icon(Icons.movie, color: Colors.white24, size: 40)),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, Color(0xDD000000)],
                  begin: Alignment.center,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            Positioned(
              left: 12, right: 4, bottom: 8,
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(project.name,
                            maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text(formatMs(project.edit.totalDurationMs),
                            style: const TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                  ),
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.more_vert, size: 20),
                    onSelected: (v) => _menu(context, v),
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'rename', child: Text('Rename')),
                      PopupMenuItem(value: 'delete', child: Text('Delete')),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _menu(BuildContext context, String action) async {
    final controller = context.read<ProjectsController>();
    if (action == 'delete') {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Delete project?'),
          content: const Text('This removes the project and its imported media from the app.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
          ],
        ),
      );
      if (ok == true) await controller.delete(project.id);
    } else {
      final text = TextEditingController(text: project.name);
      final name = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Rename project'),
          content: TextField(controller: text, autofocus: true),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, text.text), child: const Text('Save')),
          ],
        ),
      );
      text.dispose();
      if (name != null) await controller.rename(project.id, name);
    }
  }
}
