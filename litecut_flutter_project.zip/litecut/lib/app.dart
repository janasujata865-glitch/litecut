import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'controllers/projects_controller.dart';
import 'core/theme.dart';
import 'screens/home_screen.dart';
import 'services/media_service.dart';
import 'services/project_repository.dart';

/// Root widget. Wires up the long-lived services and the project list controller.
class LiteCutApp extends StatelessWidget {
  const LiteCutApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<ProjectRepository>(create: (_) => ProjectRepository()),
        Provider<MediaService>(create: (_) => MediaService()),
        ChangeNotifierProvider<ProjectsController>(
          create: (ctx) => ProjectsController(
            ctx.read<ProjectRepository>(),
            ctx.read<MediaService>(),
          )..load(),
        ),
      ],
      child: MaterialApp(
        title: 'LiteCut',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const HomeScreen(),
      ),
    );
  }
}
