import 'package:flutter/foundation.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../models/edit_state.dart';
import '../models/project.dart';
import '../services/export_service.dart';

enum ExportStatus { idle, rendering, saving, done, failed, cancelled }

class ExportController extends ChangeNotifier {
  ExportController({required this.project, required this.edit});

  final Project project;
  final EditState edit;
  final ExportService _service = ExportService();

  ExportSettings settings = const ExportSettings();
  ExportStatus status = ExportStatus.idle;
  double progress = 0;
  String? error;

  bool get busy => status == ExportStatus.rendering || status == ExportStatus.saving;

  /// Output size preview for the settings screen.
  (int, int) get outputSize =>
      ExportService.outputSize(project.width, project.height, settings.resolution);

  void updateSettings(ExportSettings s) {
    settings = s;
    notifyListeners();
  }

  Future<void> start() async {
    status = ExportStatus.rendering;
    progress = 0;
    error = null;
    notifyListeners();
    await WakelockPlus.enable(); // don't let the screen sleep mid-render
    try {
      final path = await _service.export(
        project: project,
        edit: edit,
        settings: settings,
        onProgress: (v) {
          progress = v;
          notifyListeners();
        },
      );
      status = ExportStatus.saving;
      progress = 1;
      notifyListeners();
      await _service.saveToGallery(path);
      status = ExportStatus.done;
    } on ExportCancelled {
      status = ExportStatus.cancelled;
    } catch (e) {
      status = ExportStatus.failed;
      error = e.toString();
    } finally {
      await WakelockPlus.disable();
    }
    notifyListeners();
  }

  Future<void> cancel() => _service.cancel();
}
