import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../models/edit_state.dart';
import '../models/project.dart';
import '../services/media_service.dart';
import '../services/project_repository.dart';

/// State for the Home screen: the list of projects + importing new videos.
class ProjectsController extends ChangeNotifier {
  ProjectsController(this._repo, this._media);

  final ProjectRepository _repo;
  final MediaService _media;
  static const _uuid = Uuid();

  List<Project> projects = [];
  bool loading = true;
  bool importing = false;

  Future<void> load() async {
    projects = await _repo.load();
    _sort();
    loading = false;
    notifyListeners();
  }

  void refresh() {
    _sort();
    notifyListeners();
  }

  void _sort() => projects.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));

  /// Gallery picker -> copy into app storage -> probe -> thumbnail -> new Project.
  /// Returns null if the user cancelled the picker.
  Future<Project?> createFromGallery() async {
    final picked = await _media.pickVideo();
    if (picked == null) return null;

    importing = true;
    notifyListeners();
    try {
      final id = _uuid.v4();
      final dir = await _repo.projectDir(id);

      // Picker results live in a cache folder the OS may purge -> copy.
      final dest = p.join(dir.path, 'source${p.extension(picked)}');
      await File(picked).copy(dest);
      try {
        await File(picked).delete();
      } catch (_) {}

      final meta = await _media.readVideoMeta(dest);
      final hasAudio = await _media.hasAudioStream(dest);
      final thumb = await _media.extractThumbnail(dest, p.join(dir.path, 'thumb.jpg'));

      final now = DateTime.now();
      final project = Project(
        id: id,
        name: 'Project ${now.day}/${now.month} ${now.hour}:${now.minute.toString().padLeft(2, '0')}',
        sourcePath: dest,
        thumbnailPath: thumb,
        sourceDurationMs: meta.durationMs,
        width: meta.width,
        height: meta.height,
        hasAudio: hasAudio,
        createdAt: now,
        updatedAt: now,
        edit: EditState.initial(meta.durationMs, _uuid.v4()),
      );
      projects.insert(0, project);
      await _repo.save(projects);
      return project;
    } finally {
      importing = false;
      notifyListeners();
    }
  }

  /// Called by the editor (debounced autosave). [notify] is false when called
  /// during widget disposal; Home calls [refresh] when it regains focus.
  Future<void> update(Project project, {bool notify = true}) async {
    final i = projects.indexWhere((e) => e.id == project.id);
    if (i < 0) return;
    projects[i] = project;
    await _repo.save(projects);
    if (notify) notifyListeners();
  }

  Future<void> rename(String id, String name) async {
    final i = projects.indexWhere((e) => e.id == id);
    if (i < 0 || name.trim().isEmpty) return;
    await update(projects[i].copyWith(name: name.trim()));
  }

  Future<void> delete(String id) async {
    projects.removeWhere((e) => e.id == id);
    notifyListeners();
    await _repo.save(projects);
    await _repo.deleteProjectFiles(id);
  }
}
