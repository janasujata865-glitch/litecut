import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';
import 'package:video_player/video_player.dart';

import '../core/format.dart';
import '../models/clip_segment.dart';
import '../models/edit_state.dart';
import '../models/music_track.dart';
import '../models/project.dart';
import '../models/text_overlay.dart';
import '../services/media_service.dart';
import '../services/project_repository.dart';
import 'projects_controller.dart';

const _uuid = Uuid();

/// Shortest clip the editor allows (prevents zero-length segments).
const int kMinSegmentMs = 300;

/// All editing logic + the preview playback engine. The UI only reads state
/// and calls methods; it contains no editing rules.
///
/// PLAYBACK / SYNC DESIGN
/// ----------------------
/// `video_player` only reports its position ~2x per second, which is far too
/// coarse for a smooth playhead or exact segment cuts. So a wall-clock
/// ([_clock]) is the MASTER timeline clock (ticked every ~33 ms):
///   * timeline time -> (segment, source time) via [EditState.locate]
///   * crossing into a non-contiguous segment => seek the video, pause the clock
///     until the seek completes, then resume (no drift is accumulated)
///   * the video player and the music player are both SLAVES: every ~1 s their
///     estimated position is compared with where they should be, and re-seeked
///     if they've drifted more than a few hundred ms.
class EditorController extends ChangeNotifier {
  EditorController({
    required Project project,
    required ProjectsController projects,
    required MediaService media,
    required ProjectRepository repo,
  })  : _project = project,
        _projects = projects,
        _media = media,
        _repo = repo,
        _state = project.edit;

  final ProjectsController _projects;
  final MediaService _media;
  final ProjectRepository _repo;

  Project _project;
  Project get project => _project;

  // ------------------------------------------------------------------ state
  EditState _state;
  EditState get state => _state;
  final List<EditState> _undo = [];
  final List<EditState> _redo = [];
  bool get canUndo => _undo.isNotEmpty;
  bool get canRedo => _redo.isNotEmpty;

  VideoPlayerController? _video;
  VideoPlayerController get video => _video!;
  VideoPlayerController? _audio;
  String? _audioPath;
  _PositionTracker? _videoTracker;
  _PositionTracker? _audioTracker;

  bool ready = false;
  String? initError;
  bool isPlaying = false;
  bool _disposed = false;

  int _positionMs = 0;
  int get positionMs => _positionMs;
  int get totalMs => _state.totalDurationMs;

  String? selectedSegmentId;
  String? selectedOverlayId;
  double pixelsPerSecond = 80;
  List<String> filmstrip = const [];

  // playback internals
  Timer? _ticker;
  Timer? _saveTimer;
  final Stopwatch _clock = Stopwatch();
  final Stopwatch _sw = Stopwatch()..start(); // free-running, for timestamps
  int _playOriginMs = 0;
  int _activeSeg = -1;
  bool _busy = false; // clock frozen while a seek completes
  bool _musicBusy = false;
  int _lastSeekAt = 0;
  int _lastDriftCheck = 0;
  int _lastMusicCheck = 0;
  bool _seeking = false;
  int? _pendingSeekMs;
  EditState? _gestureStart;
  Future<void> _musicLoad = Future.value();

  // --------------------------------------------------------------- lifecycle
  Future<void> init() async {
    try {
      // mixWithOthers: true on BOTH players, otherwise on Android the second
      // player steals audio focus and pauses the first one.
      final v = VideoPlayerController.file(
        File(_project.sourcePath),
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
      );
      _video = v;
      await v.initialize();
      await v.setLooping(false);
      await v.setVolume(_state.originalVolume);
      _videoTracker = _PositionTracker(v);

      _queueMusicSync();
      await _musicLoad;

      ready = true;
      await _applySeek(0);
      _notify();
      unawaited(_loadFilmstrip());
    } catch (e) {
      initError = '$e';
      _notify();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _ticker?.cancel();
    _saveTimer?.cancel();
    _flushSave(notify: false);
    _videoTracker?.dispose();
    _audioTracker?.dispose();
    _video?.dispose();
    _audio?.dispose();
    super.dispose();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  Future<void> _loadFilmstrip() async {
    final dir = await _repo.projectDir(_project.id);
    final out = Directory(p.join(dir.path, 'strip'))..createSync(recursive: true);
    filmstrip = await _media.generateFilmstrip(
        _project.sourcePath, out, _project.sourceDurationMs);
    _notify();
  }

  // ---------------------------------------------------------------- playback
  Future<void> togglePlay() => isPlaying ? pause() : play();

  Future<void> play() async {
    if (!ready || isPlaying || totalMs <= 0) return;
    if (_positionMs >= totalMs - 50) _positionMs = 0;
    isPlaying = true;
    _notify();
    await _applySeek(_positionMs); // line both players up first
    if (!isPlaying) return;
    await video.play();
    _restartClock();
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(milliseconds: 33), (_) => _tick());
  }

  Future<void> pause() async {
    _ticker?.cancel();
    _ticker = null;
    _clock.stop();
    if (isPlaying) {
      isPlaying = false;
      _notify();
    }
    await _video?.pause();
    await _audio?.pause();
  }

  void _restartClock() {
    _playOriginMs = _positionMs;
    _clock
      ..reset()
      ..start();
  }

  void _tick() {
    if (!isPlaying || _busy) return;
    final t = _playOriginMs + _clock.elapsedMilliseconds;
    if (t >= totalMs) {
      _positionMs = totalMs;
      unawaited(pause());
      return;
    }
    _positionMs = t;
    final loc = _state.locate(t);
    if (loc.index != _activeSeg) {
      unawaited(_enterSegment(loc));
    } else {
      _driftCheck(loc);
    }
    unawaited(_syncMusic());
    _notify();
  }

  /// Playback crossed into another segment.
  Future<void> _enterSegment(({int index, int offsetMs}) loc) async {
    final segs = _state.segments;
    final prevIndex = _activeSeg;
    final prev = (prevIndex >= 0 && prevIndex < segs.length) ? segs[prevIndex] : null;
    final seg = segs[loc.index];
    _activeSeg = loc.index;

    // Contiguous in the source (e.g. after a plain split): keep playing, no seek.
    final contiguous =
        prev != null && loc.index == prevIndex + 1 && prev.endMs == seg.startMs;

    _busy = true;
    try {
      if (!contiguous) {
        await _setPreviewSpeed(seg.speed);
        await video.seekTo(Duration(milliseconds: _srcClamp(seg.startMs + (loc.offsetMs * seg.speed).round())));
        _lastSeekAt = _sw.elapsedMilliseconds;
      } else if (prev.speed != seg.speed) {
        await _setPreviewSpeed(seg.speed);
      }
      await _syncMusic(force: !contiguous);
    } finally {
      _busy = false;
    }
    if (isPlaying) _restartClock(); // resume exactly where the timeline was
  }

  void _driftCheck(({int index, int offsetMs}) loc) {
    final now = _sw.elapsedMilliseconds;
    if (now - _lastSeekAt < 1500 || now - _lastDriftCheck < 1000) return;
    _lastDriftCheck = now;
    final seg = _state.segments[loc.index];
    final expected = seg.startMs + (loc.offsetMs * seg.speed).round();
    final actual = _videoTracker?.estimate() ?? expected;
    if ((actual - expected).abs() > 400) {
      _lastSeekAt = now;
      unawaited(video.seekTo(Duration(milliseconds: _srcClamp(expected))));
    }
  }

  int _srcClamp(int ms) => clampInt(ms, 0, _project.sourceDurationMs);

  /// Previews slow-mo / fast-forward by changing the player's playback rate.
  /// Platforms differ in the rates they accept; export always uses exact values.
  Future<void> _setPreviewSpeed(double s) async {
    final speed = clampDouble(s, 0.25, 4.0);
    try {
      await video.setPlaybackSpeed(speed);
    } catch (_) {
      try {
        await video.setPlaybackSpeed(1.0);
      } catch (_) {}
    }
  }

  /// Scrub / seek. Rapid calls (finger dragging the timeline) are coalesced:
  /// only the most recent target is applied once the previous seek finishes.
  Future<void> scrubTo(int ms) async {
    if (!ready) return;
    _positionMs = clampInt(ms, 0, totalMs);
    _notify();
    _pendingSeekMs = _positionMs;
    if (_seeking) return;
    _seeking = true;
    try {
      while (_pendingSeekMs != null) {
        final target = _pendingSeekMs!;
        _pendingSeekMs = null;
        await _applySeek(target);
      }
    } finally {
      _seeking = false;
    }
  }

  Future<void> _applySeek(int timelineMs) async {
    if (_state.segments.isEmpty) return;
    final loc = _state.locate(timelineMs);
    final seg = _state.segments[loc.index];
    _activeSeg = loc.index;
    await _setPreviewSpeed(seg.speed);
    await video.seekTo(Duration(
        milliseconds: _srcClamp(seg.startMs + (loc.offsetMs * seg.speed).round())));
    _lastSeekAt = _sw.elapsedMilliseconds;
    await _syncMusic(force: true);
    if (isPlaying) _restartClock();
  }

  /// Re-aligns the preview frame (e.g. after closing the trim sheet).
  void refreshPreview() {
    if (!isPlaying) unawaited(scrubTo(_positionMs));
  }

  /// Show a raw SOURCE frame while dragging trim handles.
  void peekSource(int sourceMs) {
    unawaited(_video?.seekTo(Duration(milliseconds: _srcClamp(sourceMs))));
  }

  // -------------------------------------------------------- music (slave)
  /// Starts/stops/re-seeks the music player so it matches the master timeline.
  Future<void> _syncMusic({bool force = false}) async {
    final a = _audio;
    final m = _state.music;
    if (a == null || m == null || _musicBusy) return;
    _musicBusy = true;
    try {
      final want = _positionMs - m.timelineStartMs; // position inside the audio file
      final shouldPlay = isPlaying && want >= 0 && want < m.durationMs;
      if (shouldPlay) {
        if (!a.value.isPlaying || force) {
          await a.seekTo(Duration(milliseconds: want));
          await a.play();
          _lastMusicCheck = _sw.elapsedMilliseconds;
        } else if (_sw.elapsedMilliseconds - _lastMusicCheck > 1500) {
          _lastMusicCheck = _sw.elapsedMilliseconds;
          final actual = _audioTracker?.estimate() ?? want;
          if ((actual - want).abs() > 350) {
            await a.seekTo(Duration(milliseconds: want));
          }
        }
      } else if (a.value.isPlaying) {
        await a.pause();
      }
    } finally {
      _musicBusy = false;
    }
  }

  void _queueMusicSync() {
    _musicLoad = _musicLoad.then((_) => _syncMusicController());
  }

  Future<void> _syncMusicController() async {
    final music = _state.music;
    final path = music?.path;
    if (path == _audioPath) {
      await _audio?.setVolume(music?.volume ?? 1.0);
      return;
    }
    _audioPath = path;
    final old = _audio;
    _audio = null;
    _audioTracker?.dispose();
    _audioTracker = null;
    await old?.pause();
    await old?.dispose();
    if (path == null || music == null) return;

    final c = VideoPlayerController.file(
      File(path),
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    );
    try {
      await c.initialize();
      await c.setVolume(music.volume);
      _audio = c;
      _audioTracker = _PositionTracker(c);
    } catch (_) {
      await c.dispose();
      _audioPath = null;
    }
  }

  void _applyVolumes() {
    unawaited(_video?.setVolume(_state.originalVolume));
    unawaited(_audio?.setVolume(_state.music?.volume ?? 1.0));
  }

  // ------------------------------------------------------- history / commits
  void _commit(EditState next, {int? positionMs}) {
    if (isPlaying) unawaited(pause());
    _undo.add(_state);
    if (_undo.length > 60) _undo.removeAt(0);
    _redo.clear();
    _setState(next, positionMs: positionMs);
  }

  void _setState(EditState next, {int? positionMs}) {
    _state = next;
    _positionMs = clampInt(positionMs ?? _positionMs, 0, totalMs);
    if (selectedSegmentId != null &&
        !_state.segments.any((s) => s.id == selectedSegmentId)) {
      selectedSegmentId = null;
    }
    if (selectedOverlayId != null &&
        !_state.overlays.any((o) => o.id == selectedOverlayId)) {
      selectedOverlayId = null;
    }
    _applyVolumes();
    _queueMusicSync();
    _scheduleSave();
    _notify();
    if (!isPlaying) unawaited(scrubTo(_positionMs));
  }

  void undo() {
    if (_undo.isEmpty) return;
    _redo.add(_state);
    _setState(_undo.removeLast());
  }

  void redo() {
    if (_redo.isEmpty) return;
    _undo.add(_state);
    _setState(_redo.removeLast());
  }

  /// For continuous controls (sliders, dragging text, typing): apply changes
  /// live WITHOUT creating an undo step per tick...
  void liveUpdate(EditState Function(EditState s) change) {
    _gestureStart ??= _state;
    _state = change(_state);
    _applyVolumes();
    _scheduleSave();
    _notify();
  }

  /// ...then call this when the gesture ends to record ONE undo step.
  void commitGesture() {
    final start = _gestureStart;
    _gestureStart = null;
    if (start == null) return;
    if (!identical(start, _state)) {
      _undo.add(start);
      if (_undo.length > 60) _undo.removeAt(0);
      _redo.clear();
    }
    _notify();
  }

  void _scheduleSave() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 700), _flushSave);
  }

  void _flushSave({bool notify = true}) {
    _project = _project.copyWith(edit: _state, updatedAt: DateTime.now());
    unawaited(_projects.update(_project, notify: notify));
  }

  // ---------------------------------------------------------------- selection
  void selectSegment(String? id) {
    selectedSegmentId = selectedSegmentId == id ? null : id;
    selectedOverlayId = null;
    _notify();
  }

  void selectOverlay(String? id) {
    selectedOverlayId = id;
    selectedSegmentId = null;
    _notify();
  }

  /// The clip tools act on: the selected one, else the one under the playhead.
  ClipSegment? get targetSegment {
    final segs = _state.segments;
    if (segs.isEmpty) return null;
    if (selectedSegmentId != null) {
      for (final s in segs) {
        if (s.id == selectedSegmentId) return s;
      }
    }
    return segs[_state.locate(_positionMs).index];
  }

  void zoomIn() => _zoom(1.4);
  void zoomOut() => _zoom(1 / 1.4);
  void _zoom(double f) {
    pixelsPerSecond = clampDouble(pixelsPerSecond * f, 20, 300);
    _notify();
  }

  // ---------------------------------------------------- split / trim / delete
  /// Splits the clip under the playhead in two. Returns an error message or null.
  String? splitAtPlayhead() {
    final loc = _state.locate(_positionMs);
    final seg = _state.segments[loc.index];
    final cut = seg.startMs + (loc.offsetMs * seg.speed).round();
    if (cut - seg.startMs < kMinSegmentMs || seg.endMs - cut < kMinSegmentMs) {
      return 'Move the playhead inside a clip (not at its very edge) to split.';
    }
    final left = seg.copyWith(endMs: cut);
    final right = seg.copyWith(id: _uuid.v4(), startMs: cut);
    final segs = [..._state.segments]..replaceRange(loc.index, loc.index + 1, [left, right]);
    selectedSegmentId = right.id;
    _commit(_state.copyWith(segments: segs));
    return null;
  }

  /// Cuts everything BEFORE the playhead out of the current clip.
  String? trimStartToPlayhead() {
    final loc = _state.locate(_positionMs);
    final seg = _state.segments[loc.index];
    final cut = seg.startMs + (loc.offsetMs * seg.speed).round();
    if (cut - seg.startMs <= 0) return 'The playhead is already at the start of this clip.';
    if (seg.endMs - cut < kMinSegmentMs) return 'That would leave the clip too short.';
    final next = _state.updateSegment(seg.id, (s) => s.copyWith(startMs: cut));
    _commit(next, positionMs: next.segmentStartOnTimeline(loc.index));
    return null;
  }

  /// Cuts everything AFTER the playhead out of the current clip.
  String? trimEndToPlayhead() {
    final loc = _state.locate(_positionMs);
    final seg = _state.segments[loc.index];
    final cut = seg.startMs + (loc.offsetMs * seg.speed).round();
    if (cut - seg.startMs < kMinSegmentMs) return 'That would leave the clip too short.';
    if (seg.endMs - cut <= 0) return 'The playhead is already at the end of this clip.';
    _commit(_state.updateSegment(seg.id, (s) => s.copyWith(endMs: cut)));
    return null;
  }

  /// How far a clip's handles may move without overlapping its neighbours.
  ({int min, int max}) trimBounds(String id) {
    final segs = _state.segments;
    final i = segs.indexWhere((s) => s.id == id);
    final lo = i > 0 ? segs[i - 1].endMs : 0;
    final hi = (i >= 0 && i < segs.length - 1) ? segs[i + 1].startMs : _project.sourceDurationMs;
    return (min: lo, max: hi);
  }

  String? applyTrim(String id, int startMs, int endMs) {
    if (endMs - startMs < kMinSegmentMs) return 'Clip must be at least 0.3 seconds.';
    final next = _state.updateSegment(id, (s) => s.copyWith(startMs: startMs, endMs: endMs));
    final idx = next.segments.indexWhere((s) => s.id == id);
    _commit(next, positionMs: next.segmentStartOnTimeline(idx));
    return null;
  }

  String? deleteSelectedSegment() {
    if (_state.segments.length <= 1) return 'A project needs at least one clip.';
    final seg = targetSegment!;
    final idx = _state.segments.indexWhere((s) => s.id == seg.id);
    final start = _state.segmentStartOnTimeline(idx);
    selectedSegmentId = null;
    _commit(
      _state.copyWith(segments: [..._state.segments]..removeAt(idx)),
      positionMs: start,
    );
    return null;
  }

  void setSpeed(String id, double speed, {bool allClips = false}) {
    final next = allClips
        ? _state.copyWith(segments: [for (final s in _state.segments) s.copyWith(speed: speed)])
        : _state.updateSegment(id, (s) => s.copyWith(speed: speed));
    _commit(next);
  }

  // -------------------------------------------------------------------- audio
  Future<String?> addMusic() async {
    final picked = await _media.pickAudio();
    if (picked == null) return null;
    final dir = await _repo.projectDir(_project.id);
    final dest = p.join(dir.path, 'music_${_uuid.v4()}${p.extension(picked.path)}');
    await File(picked.path).copy(dest);

    final probe = VideoPlayerController.file(File(dest));
    int durationMs;
    try {
      await probe.initialize();
      durationMs = probe.value.duration.inMilliseconds;
    } catch (_) {
      try {
        await File(dest).delete();
      } catch (_) {}
      return 'Could not read that audio file.';
    } finally {
      await probe.dispose();
    }

    _commit(_state.copyWith(
      music: MusicTrack(
        path: dest,
        name: picked.name,
        durationMs: durationMs,
        timelineStartMs: _positionMs,
      ),
    ));
    return null;
  }

  void removeMusic() => _commit(_state.copyWith(clearMusic: true));

  void liveMusicVolume(double v) =>
      liveUpdate((s) => s.copyWith(music: s.music?.copyWith(volume: v)));
  void liveMusicStart(int ms) =>
      liveUpdate((s) => s.copyWith(music: s.music?.copyWith(timelineStartMs: ms)));
  void liveOriginalVolume(double v) => liveUpdate((s) => s.copyWith(originalVolume: v));

  // --------------------------------------------------------------------- text
  TextOverlay addText() {
    final start = clampInt(_positionMs, 0, math.max(0, totalMs - 1000));
    final end = math.min(start + 3000, totalMs);
    final overlay = TextOverlay(id: _uuid.v4(), text: 'Your text', startMs: start, endMs: end);
    selectedOverlayId = overlay.id;
    _commit(_state.copyWith(overlays: [..._state.overlays, overlay]));
    return overlay;
  }

  void liveUpdateOverlay(String id, TextOverlay Function(TextOverlay) f) =>
      liveUpdate((s) => s.updateOverlay(id, f));

  void deleteOverlay(String id) {
    _commit(_state.copyWith(overlays: _state.overlays.where((o) => o.id != id).toList()));
  }

  /// Called when the text sheet closes: records one undo step, drops empty captions.
  void finishTextEdit(String id) {
    commitGesture();
    final o = _state.overlays.where((e) => e.id == id).firstOrNull;
    if (o != null && o.text.trim().isEmpty) deleteOverlay(id);
  }
}

/// Estimates a player's CURRENT position between its coarse position updates.
class _PositionTracker {
  _PositionTracker(this.controller) {
    controller.addListener(_onChange);
  }

  final VideoPlayerController controller;
  final Stopwatch _sw = Stopwatch()..start();
  Duration? _last;
  int _posMs = 0;
  int _atMs = 0;

  void _onChange() {
    final pos = controller.value.position;
    if (pos != _last) {
      _last = pos;
      _posMs = pos.inMilliseconds;
      _atMs = _sw.elapsedMilliseconds;
    }
  }

  int estimate() {
    final v = controller.value;
    if (!v.isPlaying) return v.position.inMilliseconds;
    return _posMs + ((_sw.elapsedMilliseconds - _atMs) * v.playbackSpeed).round();
  }

  void dispose() => controller.removeListener(_onChange);
}
