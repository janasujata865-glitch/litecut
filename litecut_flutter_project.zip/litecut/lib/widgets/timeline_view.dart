import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/editor_controller.dart';
import '../core/format.dart';
import '../core/theme.dart';
import '../models/clip_segment.dart';
import '../models/text_overlay.dart';

/// CapCut-style timeline: the playhead is fixed in the centre and the tracks
/// scroll beneath it.
///   * playing  -> the scroll offset follows the controller's position
///   * dragging -> the controller follows the scroll offset (scrubbing)
/// pixels = milliseconds / 1000 * pixelsPerSecond (no other conversions).
class TimelineView extends StatefulWidget {
  const TimelineView({super.key, required this.onEditOverlay, required this.onOpenAudio});
  final void Function(String overlayId) onEditOverlay;
  final VoidCallback onOpenAudio;

  @override
  State<TimelineView> createState() => _TimelineViewState();
}

class _TimelineViewState extends State<TimelineView> {
  final ScrollController _scroll = ScrollController();
  bool _userScrolling = false;

  static const double _rulerH = 22;
  static const double _trackH = 56;
  static const double _laneH = 24;

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  /// Greedy lane packing so overlapping captions are drawn on separate rows.
  ({Map<String, int> lanes, int count}) _packLanes(List<TextOverlay> overlays) {
    final sorted = [...overlays]..sort((a, b) => a.startMs.compareTo(b.startMs));
    final ends = <int>[];
    final map = <String, int>{};
    for (final o in sorted) {
      var lane = ends.indexWhere((e) => e <= o.startMs);
      if (lane == -1) {
        ends.add(o.endMs);
        lane = ends.length - 1;
      } else {
        ends[lane] = o.endMs;
      }
      map[o.id] = lane;
    }
    return (lanes: map, count: ends.length);
  }

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    final pps = c.pixelsPerSecond;
    final packed = _packLanes(c.state.overlays);
    final height = _rulerH + 6 + _trackH + 6 + _laneH + 2 + packed.count * (_laneH + 2) + 8;

    // Keep the scroll position glued to the playhead when we're not being dragged.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _userScrolling || !_scroll.hasClients) return;
      final target = math.min(math.max(c.positionMs / 1000 * pps, 0.0), _scroll.position.maxScrollExtent);
      if ((_scroll.offset - target).abs() > 0.5) _scroll.jumpTo(target);
    });

    return Container(
      height: height,
      color: AppColors.background,
      child: LayoutBuilder(
        builder: (context, box) {
          final half = box.maxWidth / 2;
          final contentW = math.max(1.0, c.totalMs / 1000 * pps);

          return Stack(
            children: [
              NotificationListener<ScrollNotification>(
                onNotification: (n) {
                  final ctl = context.read<EditorController>();
                  if (n is ScrollStartNotification && n.dragDetails != null) {
                    _userScrolling = true;
                    if (ctl.isPlaying) ctl.pause();
                  } else if (n is ScrollUpdateNotification && _userScrolling) {
                    ctl.scrubTo((_scroll.offset / pps * 1000).round());
                  } else if (n is ScrollEndNotification) {
                    _userScrolling = false;
                  }
                  return false;
                },
                child: SingleChildScrollView(
                  controller: _scroll,
                  scrollDirection: Axis.horizontal,
                  physics: const ClampingScrollPhysics(),
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: half),
                    child: SizedBox(
                      width: contentW,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomPaint(
                            size: Size(contentW, _rulerH),
                            painter: _RulerPainter(pps: pps, totalMs: c.totalMs),
                          ),
                          const SizedBox(height: 6),
                          _videoTrack(c, pps, contentW),
                          const SizedBox(height: 6),
                          _musicLane(c, pps, contentW),
                          const SizedBox(height: 2),
                          _textLanes(c, pps, contentW, packed),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              // fixed playhead
              Positioned(
                left: half - 1,
                top: 0,
                bottom: 0,
                width: 2,
                child: const IgnorePointer(child: ColoredBox(color: Colors.white)),
              ),
            ],
          );
        },
      ),
    );
  }

  // ------------------------------------------------------------- video track
  Widget _videoTrack(EditorController c, double pps, double contentW) {
    var left = 0.0;
    final blocks = <Widget>[];
    for (final seg in c.state.segments) {
      final w = seg.timelineDurationMs / 1000 * pps;
      blocks.add(Positioned(
        left: left,
        width: w,
        top: 0,
        bottom: 0,
        child: _SegmentBlock(
          seg: seg,
          width: w,
          selected: c.selectedSegmentId == seg.id,
          filmstrip: c.filmstrip,
          sourceDurationMs: c.project.sourceDurationMs,
          trackH: _trackH,
          onTap: () => c.selectSegment(seg.id),
        ),
      ));
      left += w;
    }
    return SizedBox(width: contentW, height: _trackH, child: Stack(children: blocks));
  }

  // -------------------------------------------------------------- music lane
  Widget _musicLane(EditorController c, double pps, double contentW) {
    final m = c.state.music;
    return SizedBox(
      width: contentW,
      height: _laneH,
      child: ClipRect(
        child: Stack(
          children: [
            if (m == null)
              Positioned.fill(
                child: GestureDetector(
                  onTap: widget.onOpenAudio,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.only(left: 8),
                    child: const Text('＋ Add audio',
                        style: TextStyle(fontSize: 11, color: Colors.white54), maxLines: 1),
                  ),
                ),
              )
            else
              Positioned(
                left: m.timelineStartMs / 1000 * pps,
                width: math.max(24, m.durationMs / 1000 * pps),
                top: 0,
                bottom: 0,
                child: GestureDetector(
                  onTap: widget.onOpenAudio,
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppColors.teal.withValues(alpha: 0.85),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    child: Row(
                      children: [
                        const Icon(Icons.music_note, size: 14),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(m.name,
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 11)),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // --------------------------------------------------------------- text lanes
  Widget _textLanes(EditorController c, double pps, double contentW,
      ({Map<String, int> lanes, int count}) packed) {
    return SizedBox(
      width: contentW,
      height: packed.count * (_laneH + 2),
      child: ClipRect(
        child: Stack(
          children: [
            for (final o in c.state.overlays)
              Positioned(
                left: o.startMs / 1000 * pps,
                width: math.max(24, (o.endMs - o.startMs) / 1000 * pps),
                top: (packed.lanes[o.id] ?? 0) * (_laneH + 2),
                height: _laneH,
                child: GestureDetector(
                  onTap: () {
                    c.selectOverlay(o.id);
                    widget.onEditOverlay(o.id);
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppColors.amber.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(6),
                      border: c.selectedOverlayId == o.id
                          ? Border.all(color: Colors.white, width: 1.5)
                          : null,
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    alignment: Alignment.centerLeft,
                    child: Text(o.text,
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11, color: Colors.black)),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _SegmentBlock extends StatelessWidget {
  const _SegmentBlock({
    required this.seg,
    required this.width,
    required this.selected,
    required this.filmstrip,
    required this.sourceDurationMs,
    required this.trackH,
    required this.onTap,
  });

  final ClipSegment seg;
  final double width;
  final bool selected;
  final List<String> filmstrip;
  final int sourceDurationMs;
  final double trackH;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 0.5),
        foregroundDecoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          border: selected ? Border.all(color: Colors.white, width: 2) : null,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: Stack(
            fit: StackFit.expand,
            children: [
              _strip(),
              if ((seg.speed - 1).abs() > 0.01)
                Positioned(
                  left: 4,
                  top: 3,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text('${seg.speed.toStringAsFixed(seg.speed % 1 == 0 ? 0 : 2)}x',
                        style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700)),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  /// Draws the part of the source filmstrip that this segment covers.
  /// Tile count is capped (~60 per segment) so very long clips stay cheap.
  Widget _strip() {
    if (filmstrip.isEmpty || sourceDurationMs <= 0) {
      return const ColoredBox(color: AppColors.surfaceHigh);
    }
    final tileW = math.max(trackH, width / 60);
    final n = math.max(1, (width / tileW).ceil());
    return Row(
      children: [
        for (var j = 0; j < n; j++)
          Expanded(
            child: Image.file(
              File(filmstrip[math.min(
                filmstrip.length - 1,
                ((seg.startMs + (j + 0.5) / n * seg.sourceDurationMs) / sourceDurationMs * filmstrip.length).floor(),
              )]),
              fit: BoxFit.cover,
              height: trackH,
              cacheHeight: 120,
              gaplessPlayback: true,
            ),
          ),
      ],
    );
  }
}

class _RulerPainter extends CustomPainter {
  _RulerPainter({required this.pps, required this.totalMs});
  final double pps;
  final int totalMs;

  @override
  void paint(Canvas canvas, Size size) {
    final step = pps >= 100 ? 1 : (pps >= 50 ? 2 : (pps >= 25 ? 5 : 10)); // seconds
    final paint = Paint()
      ..color = Colors.white24
      ..strokeWidth = 1;
    for (var s = 0; s * 1000 <= totalMs; s += step) {
      final x = s * pps;
      canvas.drawLine(Offset(x, size.height - 7), Offset(x, size.height), paint);
      final tp = TextPainter(
        text: TextSpan(text: formatMs(s * 1000), style: const TextStyle(fontSize: 10, color: Colors.white54)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(x + 3, 2));
    }
  }

  @override
  bool shouldRepaint(_RulerPainter old) => old.pps != pps || old.totalMs != totalMs;
}
