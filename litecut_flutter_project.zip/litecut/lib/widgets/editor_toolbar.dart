import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/editor_controller.dart';
import '../core/format.dart';
import '../core/theme.dart';
import 'sheets/sheets.dart';

/// Bottom tool strip. Each tool just calls a controller method and shows the
/// error message (if any) the controller returns.
class EditorToolbar extends StatelessWidget {
  const EditorToolbar({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    return Container(
      color: AppColors.surface,
      height: 76,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        children: [
          _Tool(Icons.content_cut, 'Split', () => showToast(context, c.splitAtPlayhead())),
          _Tool(Icons.first_page, 'Trim start', () => showToast(context, c.trimStartToPlayhead())),
          _Tool(Icons.last_page, 'Trim end', () => showToast(context, c.trimEndToPlayhead())),
          _Tool(Icons.crop, 'Trim', () => openTrimSheet(context)),
          _Tool(Icons.speed, 'Speed', () => openSpeedSheet(context)),
          _Tool(Icons.music_note, 'Audio', () => openAudioSheet(context)),
          _Tool(Icons.title, 'Text', () {
            final o = c.addText();
            openTextSheet(context, o.id);
          }),
          _Tool(Icons.delete_outline, 'Delete', () => showToast(context, c.deleteSelectedSegment())),
        ],
      ),
    );
  }
}

class _Tool extends StatelessWidget {
  const _Tool(this.icon, this.label, this.onTap);
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: SizedBox(
        width: 72,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 24),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 11), maxLines: 1),
          ],
        ),
      ),
    );
  }
}
