import 'dart:math' as math;

import 'package:flutter/foundation.dart' show clampDouble;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import '../controllers/editor_controller.dart';
import '../models/text_overlay.dart';
import '../core/theme.dart';

/// The video frame with live text overlays on top.
/// Tap = play/pause. Drag a caption to move it. Tap a caption to edit it.
class VideoPreview extends StatelessWidget {
  const VideoPreview({super.key, required this.onEditOverlay});
  final void Function(String overlayId) onEditOverlay;

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    final v = c.video;
    final visible = c.state.overlays
        .where((o) => c.positionMs >= o.startMs && c.positionMs <= o.endMs)
        .toList();

    return AspectRatio(
      aspectRatio: v.value.aspectRatio == 0 ? 16 / 9 : v.value.aspectRatio,
      child: LayoutBuilder(
        builder: (context, box) {
          final w = box.maxWidth, h = box.maxHeight;
          return ClipRect(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: c.togglePlay,
              child: Stack(
                children: [
                  Positioned.fill(child: VideoPlayer(v)),
                  for (final o in visible)
                    _OverlayItem(
                      overlay: o,
                      frameW: w,
                      frameH: h,
                      selected: c.selectedOverlayId == o.id,
                      onEdit: () => onEditOverlay(o.id),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _OverlayItem extends StatelessWidget {
  const _OverlayItem({
    required this.overlay,
    required this.frameW,
    required this.frameH,
    required this.selected,
    required this.onEdit,
  });

  final TextOverlay overlay;
  final double frameW;
  final double frameH;
  final bool selected;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final c = context.read<EditorController>();
    final shortSide = math.min(frameW, frameH);

    return Positioned(
      left: overlay.dx * frameW,
      top: overlay.dy * frameH,
      // Shift by half the child's own size so (dx, dy) is the CENTRE of the text.
      child: FractionalTranslation(
        translation: const Offset(-0.5, -0.5),
        child: GestureDetector(
          onTap: () {
            c.selectOverlay(overlay.id);
            onEdit();
          },
          onPanStart: (_) => c.selectOverlay(overlay.id),
          onPanUpdate: (d) => c.liveUpdateOverlay(
            overlay.id,
            (o) => o.copyWith(
              dx: clampDouble(o.dx + d.delta.dx / frameW, 0.0, 1.0),
              dy: clampDouble(o.dy + d.delta.dy / frameH, 0.0, 1.0),
            ),
          ),
          onPanEnd: (_) => c.commitGesture(),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: frameW * 0.9),
            child: Container(
              foregroundDecoration: selected
                  ? BoxDecoration(border: Border.all(color: AppColors.accent, width: 1.5))
                  : null,
              child: Text(
                overlay.text,
                textAlign: TextAlign.center,
                style: overlay.style(shortSide),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
