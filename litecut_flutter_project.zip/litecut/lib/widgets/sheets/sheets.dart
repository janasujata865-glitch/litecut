import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../controllers/editor_controller.dart';
import '../../core/theme.dart';
import 'audio_sheet.dart';
import 'export_sheet.dart';
import 'speed_sheet.dart';
import 'text_sheet.dart';
import 'trim_sheet.dart';

/// Modal sheets live in the Navigator's overlay (ABOVE our Provider), so the
/// controller is re-provided explicitly.
Future<T?> _open<T>(BuildContext context, Widget child, {bool dismissible = true}) {
  final c = context.read<EditorController>();
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    isDismissible: dismissible,
    enableDrag: dismissible,
    backgroundColor: AppColors.surface,
    builder: (_) => ChangeNotifierProvider<EditorController>.value(value: c, child: child),
  );
}

Future<void> openTrimSheet(BuildContext context) {
  final c = context.read<EditorController>();
  return _open(context, const TrimSheet()).whenComplete(c.refreshPreview);
}

Future<void> openSpeedSheet(BuildContext context) => _open(context, const SpeedSheet());

Future<void> openAudioSheet(BuildContext context) {
  final c = context.read<EditorController>();
  return _open(context, const AudioSheet()).whenComplete(c.commitGesture);
}

Future<void> openTextSheet(BuildContext context, String overlayId) {
  final c = context.read<EditorController>();
  return _open(context, TextSheet(overlayId: overlayId))
      .whenComplete(() => c.finishTextEdit(overlayId));
}

Future<void> openExportSheet(BuildContext context) {
  final c = context.read<EditorController>();
  return _open(
    context,
    ExportSheet(project: c.project, edit: c.state),
    dismissible: false, // closing is done via the sheet's own buttons
  );
}

/// Common padding / title / keyboard avoidance for all sheets.
class SheetFrame extends StatelessWidget {
  const SheetFrame({super.key, required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 16 + MediaQuery.viewInsetsOf(context).bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            child,
          ],
        ),
      ),
    );
  }
}
