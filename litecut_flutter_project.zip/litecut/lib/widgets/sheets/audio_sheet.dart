import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../controllers/editor_controller.dart';
import '../../core/format.dart';
import 'sheets.dart';

/// Pick background music from device storage, set its volume and start time,
/// and balance it against the video's own audio.
class AudioSheet extends StatefulWidget {
  const AudioSheet({super.key});
  @override
  State<AudioSheet> createState() => _AudioSheetState();
}

class _AudioSheetState extends State<AudioSheet> {
  bool _loading = false;

  Future<void> _pick(EditorController c) async {
    setState(() => _loading = true);
    final err = await c.addMusic();
    if (!mounted) return;
    setState(() => _loading = false);
    showToast(context, err);
  }

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    final music = c.state.music;

    return SheetFrame(
      title: 'Audio',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Video sound  ·  ${(c.state.originalVolume * 100).round()}%'),
          if (!c.project.hasAudio)
            const Text('This video has no audio track.',
                style: TextStyle(color: Colors.white54, fontSize: 12)),
          Slider(
            value: c.state.originalVolume,
            onChanged: c.project.hasAudio ? c.liveOriginalVolume : null,
            onChangeEnd: (_) => c.commitGesture(),
          ),
          const Divider(height: 28),
          if (music == null)
            SizedBox(
              width: double.infinity,
              child: FilledButton.tonalIcon(
                onPressed: _loading ? null : () => _pick(c),
                icon: _loading
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.library_music),
                label: const Text('Add music from device'),
              ),
            )
          else ...[
            Row(
              children: [
                const Icon(Icons.music_note, size: 20),
                const SizedBox(width: 8),
                Expanded(child: Text(music.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
                Text(formatMs(music.durationMs), style: const TextStyle(color: Colors.white54)),
              ],
            ),
            const SizedBox(height: 12),
            Text('Music volume  ·  ${(music.volume * 100).round()}%'),
            Slider(
              value: music.volume,
              onChanged: c.liveMusicVolume,
              onChangeEnd: (_) => c.commitGesture(),
            ),
            Text('Starts at  ·  ${formatMs(music.timelineStartMs, tenths: true)}'),
            Slider(
              min: 0,
              max: math.max(c.totalMs, 1000).toDouble(),
              value: math.min(music.timelineStartMs, math.max(c.totalMs, 1000)).toDouble(),
              onChanged: (v) => c.liveMusicStart(v.round()),
              onChangeEnd: (_) => c.commitGesture(),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _loading ? null : () => _pick(c),
                    icon: const Icon(Icons.swap_horiz),
                    label: const Text('Replace'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      c.removeMusic();
                      Navigator.pop(context);
                    },
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Remove'),
                  ),
                ),
              ],
            ),
          ],
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
          ),
        ],
      ),
    );
  }
}
