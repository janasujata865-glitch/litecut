import 'dart:math' as math;

import 'package:flutter/foundation.dart' show clampDouble;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../controllers/editor_controller.dart';
import '../../core/format.dart';
import '../../models/text_overlay.dart';
import 'sheets.dart';

/// Edit one caption: text, size, colour, style, position and visible time range.
/// (You can also drag the caption directly on the video preview.)
class TextSheet extends StatefulWidget {
  const TextSheet({super.key, required this.overlayId});
  final String overlayId;
  @override
  State<TextSheet> createState() => _TextSheetState();
}

class _TextSheetState extends State<TextSheet> {
  static const palette = <Color>[
    Colors.white, Colors.black, Color(0xFFFFEB3B), Color(0xFFFF5252), Color(0xFFFF9800),
    Color(0xFF4CAF50), Color(0xFF00E5FF), Color(0xFF448AFF), Color(0xFFB388FF), Color(0xFFFF80AB),
  ];

  late final TextEditingController _text;

  @override
  void initState() {
    super.initState();
    final o = context.read<EditorController>().state.overlays
        .firstWhere((e) => e.id == widget.overlayId);
    _text = TextEditingController(text: o.text);
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  void _live(EditorController c, TextOverlay Function(TextOverlay) f) =>
      c.liveUpdateOverlay(widget.overlayId, f);

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    final matches = c.state.overlays.where((e) => e.id == widget.overlayId);
    if (matches.isEmpty) return const SizedBox(height: 80);
    final o = matches.first;
    final total = math.max(c.totalMs, 1000).toDouble();
    final range = RangeValues(
      math.min(o.startMs.toDouble(), total),
      math.min(math.max(o.endMs.toDouble(), o.startMs + 300.0), total),
    );

    return SheetFrame(
      title: 'Text',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: _text,
            maxLines: 3,
            minLines: 1,
            decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Type your caption'),
            onChanged: (v) => _live(c, (e) => e.copyWith(text: v)),
          ),
          const SizedBox(height: 16),
          Text('Size  ·  ${o.fontSize.round()}'),
          Slider(
            min: 24,
            max: 200,
            value: clampDouble(o.fontSize, 24.0, 200.0),
            onChanged: (v) => _live(c, (e) => e.copyWith(fontSize: v)),
            onChangeEnd: (_) => c.commitGesture(),
          ),
          const Text('Colour'),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (final col in palette)
                GestureDetector(
                  onTap: () {
                    _live(c, (e) => e.copyWith(color: col));
                    c.commitGesture();
                  },
                  child: Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: col,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: o.color.toARGB32() == col.toARGB32() ? Colors.white : Colors.white24,
                        width: o.color.toARGB32() == col.toARGB32() ? 3 : 1,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Bold'),
            value: o.bold,
            onChanged: (v) {
              _live(c, (e) => e.copyWith(bold: v));
              c.commitGesture();
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Background box'),
            value: o.background,
            onChanged: (v) {
              _live(c, (e) => e.copyWith(background: v));
              c.commitGesture();
            },
          ),
          const Text('Position'),
          const SizedBox(height: 4),
          SegmentedButton<double>(
            emptySelectionAllowed: true,
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: 0.15, label: Text('Top')),
              ButtonSegment(value: 0.5, label: Text('Middle')),
              ButtonSegment(value: 0.85, label: Text('Bottom')),
            ],
            selected: {
              for (final v in const [0.15, 0.5, 0.85])
                if ((o.dy - v).abs() < 0.02) v,
            },
            onSelectionChanged: (s) {
              if (s.isEmpty) return;
              _live(c, (e) => e.copyWith(dx: 0.5, dy: s.first));
              c.commitGesture();
            },
          ),
          const Padding(
            padding: EdgeInsets.only(top: 4),
            child: Text('Tip: close this sheet and drag the text on the video to place it freely.',
                style: TextStyle(fontSize: 12, color: Colors.white54)),
          ),
          const SizedBox(height: 12),
          Text('Visible  ·  ${formatMs(range.start.round(), tenths: true)} – ${formatMs(range.end.round(), tenths: true)}'),
          RangeSlider(
            min: 0,
            max: total,
            values: range,
            onChanged: (v) {
              if (v.end - v.start < 300) return;
              _live(c, (e) => e.copyWith(startMs: v.start.round(), endMs: v.end.round()));
            },
            onChangeEnd: (_) => c.commitGesture(),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    final id = widget.overlayId;
                    Navigator.pop(context);
                    c.deleteOverlay(id);
                  },
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Delete'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
