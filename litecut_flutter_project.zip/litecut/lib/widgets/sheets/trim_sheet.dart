import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../controllers/editor_controller.dart';
import '../../core/format.dart';
import 'sheets.dart';

/// Range slider over the SOURCE video: choose the in/out points of one clip.
/// Dragging a handle shows that exact frame in the preview.
class TrimSheet extends StatefulWidget {
  const TrimSheet({super.key});
  @override
  State<TrimSheet> createState() => _TrimSheetState();
}

class _TrimSheetState extends State<TrimSheet> {
  late final String _segId;
  late final int _minB;
  late final int _maxB;
  late RangeValues _range;

  @override
  void initState() {
    super.initState();
    final c = context.read<EditorController>();
    final seg = c.targetSegment!;
    final b = c.trimBounds(seg.id);
    _segId = seg.id;
    _minB = b.min;
    _maxB = b.max;
    _range = RangeValues(seg.startMs.toDouble(), seg.endMs.toDouble());
  }

  @override
  Widget build(BuildContext context) {
    final c = context.read<EditorController>();
    final len = (_range.end - _range.start).round();
    return SheetFrame(
      title: 'Trim clip',
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('In ${formatMs(_range.start.round(), tenths: true)}'),
              Text('Length ${formatMs(len, tenths: true)}'),
              Text('Out ${formatMs(_range.end.round(), tenths: true)}'),
            ],
          ),
          RangeSlider(
            min: _minB.toDouble(),
            max: _maxB.toDouble(),
            values: _range,
            onChanged: (v) {
              if (v.end - v.start < kMinSegmentMs) return;
              final startMoved = v.start != _range.start;
              setState(() => _range = v);
              c.peekSource((startMoved ? v.start : v.end).round());
            },
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  onPressed: () {
                    final err = c.applyTrim(_segId, _range.start.round(), _range.end.round());
                    final messenger = ScaffoldMessenger.of(context);
                    Navigator.pop(context);
                    if (err != null) messenger.showSnackBar(SnackBar(content: Text(err)));
                  },
                  child: const Text('Apply'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
