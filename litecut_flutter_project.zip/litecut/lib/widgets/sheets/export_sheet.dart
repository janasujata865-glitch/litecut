import 'package:flutter/material.dart';

import '../../controllers/export_controller.dart';
import '../../models/edit_state.dart';
import '../../models/project.dart';
import '../../services/export_service.dart';
import 'sheets.dart';

/// Export options -> progress -> "saved to gallery".
class ExportSheet extends StatefulWidget {
  const ExportSheet({super.key, required this.project, required this.edit});
  final Project project;
  final EditState edit;
  @override
  State<ExportSheet> createState() => _ExportSheetState();
}

class _ExportSheetState extends State<ExportSheet> {
  late final ExportController _ec =
      ExportController(project: widget.project, edit: widget.edit);

  @override
  void dispose() {
    _ec.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ec,
      builder: (context, _) => SheetFrame(
        title: 'Export',
        child: switch (_ec.status) {
          ExportStatus.idle || ExportStatus.cancelled => _settings(),
          ExportStatus.rendering || ExportStatus.saving => _progress(),
          ExportStatus.done => _done(),
          ExportStatus.failed => _failed(),
        },
      ),
    );
  }

  Widget _settings() {
    final s = _ec.settings;
    final (w, h) = _ec.outputSize;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_ec.status == ExportStatus.cancelled)
          const Padding(padding: EdgeInsets.only(bottom: 12), child: Text('Export cancelled.')),
        const Text('Resolution'),
        const SizedBox(height: 6),
        SegmentedButton<ExportResolution>(
          showSelectedIcon: false,
          segments: const [
            ButtonSegment(value: ExportResolution.original, label: Text('Original')),
            ButtonSegment(value: ExportResolution.p1080, label: Text('1080p')),
            ButtonSegment(value: ExportResolution.p720, label: Text('720p')),
          ],
          selected: {s.resolution},
          onSelectionChanged: (v) => _ec.updateSettings(s.copyWith(resolution: v.first)),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text('Output: $w × $h', style: const TextStyle(fontSize: 12, color: Colors.white54)),
        ),
        const SizedBox(height: 16),
        const Text('Quality'),
        const SizedBox(height: 6),
        SegmentedButton<ExportQuality>(
          showSelectedIcon: false,
          segments: const [
            ButtonSegment(value: ExportQuality.high, label: Text('High')),
            ButtonSegment(value: ExportQuality.balanced, label: Text('Balanced')),
            ButtonSegment(value: ExportQuality.small, label: Text('Small')),
          ],
          selected: {s.quality},
          onSelectionChanged: (v) => _ec.updateSettings(s.copyWith(quality: v.first)),
        ),
        const SizedBox(height: 16),
        const Text('Frame rate'),
        const SizedBox(height: 6),
        SegmentedButton<int>(
          showSelectedIcon: false,
          segments: const [
            ButtonSegment(value: 24, label: Text('24')),
            ButtonSegment(value: 30, label: Text('30')),
            ButtonSegment(value: 60, label: Text('60')),
          ],
          selected: {s.fps},
          onSelectionChanged: (v) => _ec.updateSettings(s.copyWith(fps: v.first)),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Hardware encoder (faster)'),
          subtitle: const Text('Uses the phone\'s video chip. Slightly larger files.'),
          value: s.useHardwareEncoder,
          onChanged: (v) => _ec.updateSettings(s.copyWith(useHardwareEncoder: v)),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FilledButton.icon(
                onPressed: _ec.start,
                icon: const Icon(Icons.movie_creation_outlined),
                label: const Text('Export'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _progress() {
    final saving = _ec.status == ExportStatus.saving;
    return Column(
      children: [
        const SizedBox(height: 8),
        LinearProgressIndicator(value: saving ? null : _ec.progress, minHeight: 8),
        const SizedBox(height: 12),
        Text(saving ? 'Saving to gallery…' : 'Rendering… ${(_ec.progress * 100).round()}%'),
        const SizedBox(height: 4),
        const Text('Keep the app open until this finishes.',
            style: TextStyle(fontSize: 12, color: Colors.white54)),
        const SizedBox(height: 16),
        if (!saving)
          OutlinedButton(onPressed: _ec.cancel, child: const Text('Cancel')),
      ],
    );
  }

  Widget _done() => Column(
        children: [
          const Icon(Icons.check_circle, size: 56, color: Colors.greenAccent),
          const SizedBox(height: 12),
          const Text('Saved to your gallery (album “LiteCut”).'),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
          ),
        ],
      );

  Widget _failed() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(children: [
            Icon(Icons.error_outline, color: Colors.redAccent),
            SizedBox(width: 8),
            Text('Export failed'),
          ]),
          const SizedBox(height: 8),
          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 160),
            child: SingleChildScrollView(
              child: SelectableText(_ec.error ?? 'Unknown error',
                  style: const TextStyle(fontSize: 11, color: Colors.white60)),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))),
              const SizedBox(width: 12),
              Expanded(child: FilledButton(onPressed: _ec.start, child: const Text('Retry'))),
            ],
          ),
        ],
      );
}
