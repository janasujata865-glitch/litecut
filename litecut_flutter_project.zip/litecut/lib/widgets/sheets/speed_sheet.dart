import 'package:flutter/foundation.dart' show clampDouble;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../controllers/editor_controller.dart';
import 'sheets.dart';

/// Slow-motion (<1x) / fast-forward (>1x) for the selected clip.
class SpeedSheet extends StatefulWidget {
  const SpeedSheet({super.key});
  @override
  State<SpeedSheet> createState() => _SpeedSheetState();
}

class _SpeedSheetState extends State<SpeedSheet> {
  static const presets = [0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0];
  late final String _segId;
  late double _speed;
  bool _all = false;

  @override
  void initState() {
    super.initState();
    final seg = context.read<EditorController>().targetSegment!;
    _segId = seg.id;
    _speed = seg.speed;
  }

  @override
  Widget build(BuildContext context) {
    final c = context.read<EditorController>();
    return SheetFrame(
      title: 'Speed  ·  ${_speed.toStringAsFixed(2)}x',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            children: [
              for (final p in presets)
                ChoiceChip(
                  label: Text('${p}x'),
                  selected: (p - _speed).abs() < 0.01,
                  onSelected: (_) => setState(() => _speed = p),
                ),
            ],
          ),
          Slider(
            min: 0.25,
            max: 4.0,
            divisions: 15,
            value: clampDouble(_speed, 0.25, 4.0),
            label: '${_speed.toStringAsFixed(2)}x',
            onChanged: (v) => setState(() => _speed = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Apply to all clips'),
            value: _all,
            onChanged: (v) => setState(() => _all = v),
          ),
          const SizedBox(height: 4),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () {
                c.setSpeed(_segId, _speed, allClips: _all);
                Navigator.pop(context);
              },
              child: const Text('Apply'),
            ),
          ),
        ],
      ),
    );
  }
}
